import { pgTable, text, serial, integer, boolean, date, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const habits = pgTable("habits", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  name: text("name").notNull(),
  frequency: text("frequency").notNull().default("daily"), // daily, weekly, custom
  frequencyDays: json("frequency_days").$type<number[]>(), // [0,1,2,3,4,5,6] - days of week (0 = Sunday)
  reminderTime: text("reminder_time"), // HH:MM format
  createdAt: timestamp("created_at").defaultNow(),
});

export const completions = pgTable("completions", {
  id: serial("id").primaryKey(),
  habitId: integer("habit_id").notNull().references(() => habits.id),
  userId: integer("user_id").notNull().references(() => users.id),
  completedAt: date("completed_at").notNull(),
});

// User schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
});

// Habit schemas
export const insertHabitSchema = createInsertSchema(habits).pick({
  name: true,
  frequency: true,
  frequencyDays: true,
  reminderTime: true,
});

// Completion schemas
export const insertCompletionSchema = createInsertSchema(completions).pick({
  habitId: true,
  completedAt: true,
});

// Type exports
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertHabit = z.infer<typeof insertHabitSchema>;
export type Habit = typeof habits.$inferSelect;

export type InsertCompletion = z.infer<typeof insertCompletionSchema>;
export type Completion = typeof completions.$inferSelect;

// Extended types for frontend use
export interface HabitWithStreak extends Habit {
  streak: number;
  completed: boolean;
}
