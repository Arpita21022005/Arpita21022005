import { useState } from "react";
import { useLocation, Link } from "wouter";
import { Home, Calendar, BarChart, Settings, PlusCircle, User, Bell } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AddHabitDialog } from "@/components/add-habit-dialog";
import { useAuth } from "@/hooks/use-auth";
import { useIsMobile } from "@/lib/use-media-query";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function NavBar() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [addHabitOpen, setAddHabitOpen] = useState(false);
  const isMobile = useIsMobile();

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const getInitials = (name: string) => {
    return name.substring(0, 2).toUpperCase();
  };

  if (isMobile) {
    return (
      <>
        <nav className="fixed bottom-0 left-0 right-0 bg-background border-t border-border shadow-lg z-10">
          <div className="flex justify-around px-4 py-3">
            <Link href="/">
              <Button variant={location === "/" ? "default" : "ghost"} size="icon" className="flex flex-col items-center justify-center">
                <Home className="h-5 w-5" />
                <span className="text-xs mt-1">Home</span>
              </Button>
            </Link>
            
            <Link href="/calendar">
              <Button variant={location === "/calendar" ? "default" : "ghost"} size="icon" className="flex flex-col items-center justify-center">
                <Calendar className="h-5 w-5" />
                <span className="text-xs mt-1">Calendar</span>
              </Button>
            </Link>
            
            <div className="relative -mt-6">
              <Button 
                variant="default" 
                size="icon" 
                className="rounded-full h-14 w-14 shadow-lg flex flex-col items-center justify-center"
                onClick={() => setAddHabitOpen(true)}
              >
                <PlusCircle className="h-6 w-6" />
              </Button>
            </div>
            
            <Link href="/stats">
              <Button variant={location === "/stats" ? "default" : "ghost"} size="icon" className="flex flex-col items-center justify-center">
                <BarChart className="h-5 w-5" />
                <span className="text-xs mt-1">Stats</span>
              </Button>
            </Link>
            
            <Link href="/settings">
              <Button variant={location === "/settings" ? "default" : "ghost"} size="icon" className="flex flex-col items-center justify-center">
                <Settings className="h-5 w-5" />
                <span className="text-xs mt-1">Settings</span>
              </Button>
            </Link>
          </div>
        </nav>
        
        <AddHabitDialog open={addHabitOpen} onOpenChange={setAddHabitOpen} />
      </>
    );
  }

  return (
    <>
      <header className="sticky top-0 z-10 w-full border-b bg-background">
        <div className="container flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-6">
            <Link href="/">
              <Button variant="link" className="text-lg font-bold text-primary p-0">Habit Tracker</Button>
            </Link>
            
            <nav className="hidden md:flex items-center gap-6">
              <Link href="/">
                <Button variant={location === "/" ? "default" : "ghost"}>Dashboard</Button>
              </Link>
              <Link href="/calendar">
                <Button variant={location === "/calendar" ? "default" : "ghost"}>Calendar</Button>
              </Link>
              <Link href="/stats">
                <Button variant={location === "/stats" ? "default" : "ghost"}>Statistics</Button>
              </Link>
            </nav>
          </div>
          
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              className="gap-2"
              onClick={() => setAddHabitOpen(true)}
            >
              <PlusCircle className="h-4 w-4" />
              <span>Add Habit</span>
            </Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="rounded-full">
                  <Avatar>
                    <AvatarFallback>{user ? getInitials(user.username) : "UN"}</AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem className="cursor-pointer">
                  <User className="mr-2 h-4 w-4" />
                  <span>Profile</span>
                </DropdownMenuItem>
                <DropdownMenuItem className="cursor-pointer">
                  <Bell className="mr-2 h-4 w-4" />
                  <span>Notifications</span>
                </DropdownMenuItem>
                <DropdownMenuItem className="cursor-pointer">
                  <Settings className="mr-2 h-4 w-4" />
                  <span>Settings</span>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="cursor-pointer" onClick={handleLogout}>
                  <span>Logout</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>
      
      <AddHabitDialog open={addHabitOpen} onOpenChange={setAddHabitOpen} />
    </>
  );
}
