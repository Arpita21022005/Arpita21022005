import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Flame } from "lucide-react";

interface TopStreak {
  habitId: number;
  name: string;
  streak: number;
}

export function TopStreaks() {
  const { data, isLoading, error } = useQuery<TopStreak[]>({
    queryKey: ["/api/stats/streaks"],
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-semibold">Top Streaks</CardTitle>
        </CardHeader>
        <CardContent>
          {[1, 2, 3].map((i) => (
            <div key={i} className="flex items-center justify-between mb-4 last:mb-0">
              <div className="flex items-center">
                <Skeleton className="w-10 h-10 rounded-full mr-3" />
                <Skeleton className="h-4 w-24" />
              </div>
              <Skeleton className="h-4 w-16" />
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }

  if (error || !data) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-semibold">Top Streaks</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center p-4 text-muted-foreground">
            Error loading streak data.
          </div>
        </CardContent>
      </Card>
    );
  }

  // If no data, show a message
  if (data.length === 0) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-semibold">Top Streaks</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center p-4 text-muted-foreground">
            Start completing habits to build streaks!
          </div>
        </CardContent>
      </Card>
    );
  }

  // Get icon for habit
  const getHabitIcon = (habitName: string) => {
    const name = habitName.toLowerCase();
    
    if (name.includes("water") || name.includes("drink")) {
      return (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-600" viewBox="0 0 20 20" fill="currentColor">
          <path d="M3 3a1 1 0 000 2h1.22l.305 1.222a.997.997 0 00.01.042l1.358 5.43-.893.892C3.74 13.846 4.632 15 6 15h10a1 1 0 000-2H6l.379-.779 1.621-1.621a1 1 0 00.21-.39L9 5.622l1.79 7.158c.106.424.584.601.958.389l5.762-3.251a.5.5 0 00.174-.686l-2-3.464a.5.5 0 00-.615-.19L10 8.25 9 5.5 7.004 13H5.612L4.184 6.32l-.159-.636A1 1 0 003 5h-.998a1 1 0 00-.916-.599A1 1 0 000 5v.599A1 1 0 001 7h1.004l.142.569L3 13H1a1 1 0 100 2h2.004a1 1 0 00.916.599A1 1 0 005 15v-.599c0-.4.158-.766.42-1.038l1.33-1.336L5.96 15H15a1 1 0 000-2H6c-.379 0-.725-.22-.91-.55L4.89 12l-.63-2.52L3 5.62V13h1.004l1.143-4.574L5.184 8H3.67L3.016 5.24A1.001 1.001 0 003 5h27.75l-.573-2.296A1 1 0 0029.18 2H3.824a1 1 0 00-.973.732L2.28 4H1a1 1 0 000 2h1.004l.142.569L3 13H1a1 1 0 100 2h2.004a1 1 0 00.916.599A1 1 0 005 15v-.599c0-.4.158-.766.42-1.038l1.33-1.336L5.96 15H15a1 1 0 000-2H6c-.379 0-.725-.22-.91-.55L4.89 12l-.63-2.52L3 5.62V13h1.004l1.143-4.574L5.184 8H3.67L3.016 5.24A1.001 1.001 0 003 5h27.75l-.573-2.296A1 1 0 0029.18 2H3.824a1 1 0 00-.973.732L2.28 4H1a1 1 0 000 2h1.004l.142.569L3 13H1a1 1 0 100 2h2.004a1 1 0 00.916.599A1 1 0 005 15v-.599c0-.4.158-.766.42-1.038l1.33-1.336L5.96 15H15a1 1 0 000-2H6c-.379 0-.725-.22-.91-.55L4.89 12l-.63-2.52L3 5.62V13h1.004l1.143-4.574L5.184 8H3.67L3.016 5.24A1.001 1.001 0 003 5z" />
        </svg>
      );
    } else if (name.includes("meditat") || name.includes("mindful")) {
      return (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-purple-600" viewBox="0 0 20 20" fill="currentColor">
          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM7 9H5v2h2V9zm8 0h-2v2h2V9zM9 9h2v2H9V9z" clipRule="evenodd" />
        </svg>
      );
    } else if (name.includes("read") || name.includes("book")) {
      return (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-600" viewBox="0 0 20 20" fill="currentColor">
          <path d="M9 4.804A7.968 7.968 0 005.5 4c-1.255 0-2.443.29-3.5.804v10A7.969 7.969 0 015.5 14c1.669 0 3.218.51 4.5 1.385A7.962 7.962 0 0114.5 14c1.255 0 2.443.29 3.5.804v-10A7.968 7.968 0 0014.5 4c-1.255 0-2.443.29-3.5.804V12a1 1 0 11-2 0V4.804z" />
        </svg>
      );
    } else if (name.includes("exercise") || name.includes("workout") || name.includes("gym")) {
      return (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-red-600" viewBox="0 0 20 20" fill="currentColor">
          <path fillRule="evenodd" d="M6 3a1 1 0 011-1h.01a1 1 0 010 2H7a1 1 0 01-1-1zm2 3a1 1 0 00-2 0v1a2 2 0 00-2 2v1a2 2 0 00-2 2v.683a3.7 3.7 0 011.055.485 1.704 1.704 0 001.89 0 3.704 3.704 0 014.11 0 1.704 1.704 0 001.89 0 3.704 3.704 0 014.11 0 1.704 1.704 0 001.89 0A3.7 3.7 0 0118 12.683V12a2 2 0 00-2-2V9a2 2 0 00-2-2V6a1 1 0 10-2 0v1h-1V6a1 1 0 10-2 0v1H8V6zm10 8.868a3.704 3.704 0 01-4.055-.036 1.704 1.704 0 00-1.89 0 3.704 3.704 0 01-4.11 0 1.704 1.704 0 00-1.89 0A3.704 3.704 0 012 14.868V17a1 1 0 001 1h14a1 1 0 001-1v-2.132zM9 3a1 1 0 011-1h.01a1 1 0 110 2H10a1 1 0 01-1-1zm3 0a1 1 0 011-1h.01a1 1 0 110 2H13a1 1 0 01-1-1z" clipRule="evenodd" />
        </svg>
      );
    } else {
      return (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary-600" viewBox="0 0 20 20" fill="currentColor">
          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
        </svg>
      );
    }
  };

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold">Top Streaks</CardTitle>
      </CardHeader>
      <CardContent>
        {data.map((streak) => (
          <div key={streak.habitId} className="flex items-center justify-between mb-4 last:mb-0">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center mr-3">
                {getHabitIcon(streak.name)}
              </div>
              <span className="font-medium">{streak.name}</span>
            </div>

            <div className="flex items-center">
              <div className="flex items-center mr-3">
                <Flame className="h-4 w-4 text-yellow-500 mr-1" />
                <span className="font-medium">{streak.streak} day{streak.streak !== 1 ? 's' : ''}</span>
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
