import React, { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { InsertHabit } from "@shared/schema";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Badge } from "@/components/ui/badge";
import { X } from "lucide-react";

const habitSchema = z.object({
  name: z.string().min(1, "Habit name is required").max(50, "Habit name must be less than 50 characters"),
  frequency: z.enum(["daily", "weekly", "custom"]),
  frequencyDays: z.array(z.number()).optional(),
  reminderTime: z.string().optional(),
});

interface AddHabitDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const daysOfWeek = [
  { value: 0, label: "Sun" },
  { value: 1, label: "Mon" },
  { value: 2, label: "Tue" },
  { value: 3, label: "Wed" },
  { value: 4, label: "Thu" },
  { value: 5, label: "Fri" },
  { value: 6, label: "Sat" },
];

export function AddHabitDialog({ open, onOpenChange }: AddHabitDialogProps) {
  const [selectedDays, setSelectedDays] = useState<number[]>([]);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<z.infer<typeof habitSchema>>({
    resolver: zodResolver(habitSchema),
    defaultValues: {
      name: "",
      frequency: "daily",
      frequencyDays: [],
      reminderTime: "",
    },
  });

  const { watch, setValue } = form;
  const frequency = watch("frequency");

  const createHabitMutation = useMutation({
    mutationFn: async (habitData: InsertHabit) => {
      const res = await apiRequest("POST", "/api/habits", habitData);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Habit created",
        description: "Your new habit has been created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/habits/today"] });
      queryClient.invalidateQueries({ queryKey: ["/api/habits"] });
      onOpenChange(false);
      form.reset({
        name: "",
        frequency: "daily",
        frequencyDays: [],
        reminderTime: "",
      });
      setSelectedDays([]);
    },
    onError: (error) => {
      toast({
        title: "Error creating habit",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const toggleDay = (day: number) => {
    if (selectedDays.includes(day)) {
      const newSelectedDays = selectedDays.filter((d) => d !== day);
      setSelectedDays(newSelectedDays);
      setValue("frequencyDays", newSelectedDays);
    } else {
      const newSelectedDays = [...selectedDays, day];
      setSelectedDays(newSelectedDays);
      setValue("frequencyDays", newSelectedDays);
    }
  };

  const onSubmit = (values: z.infer<typeof habitSchema>) => {
    // If frequency is weekly or custom and no days are selected, default to all days
    if ((values.frequency === "weekly" || values.frequency === "custom") && (!values.frequencyDays || values.frequencyDays.length === 0)) {
      values.frequencyDays = [0, 1, 2, 3, 4, 5, 6];
    }
    
    createHabitMutation.mutate(values);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Add New Habit</DialogTitle>
          <DialogDescription>
            Create a new habit to track. Fill in the details below.
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Habit Name</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g. Morning Meditation" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="frequency"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Frequency</FormLabel>
                  <Select
                    onValueChange={(value) => {
                      field.onChange(value);
                      // Reset selected days when changing frequency
                      setSelectedDays([]);
                      setValue("frequencyDays", []);
                    }}
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select frequency" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="custom">Custom</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {(frequency === "weekly" || frequency === "custom") && (
              <FormItem>
                <FormLabel>Days of Week</FormLabel>
                <div className="flex flex-wrap gap-2 mt-2">
                  {daysOfWeek.map((day) => (
                    <Badge
                      key={day.value}
                      variant={selectedDays.includes(day.value) ? "default" : "outline"}
                      className="cursor-pointer"
                      onClick={() => toggleDay(day.value)}
                    >
                      {day.label}
                    </Badge>
                  ))}
                </div>
                {selectedDays.length === 0 && (
                  <p className="text-sm text-muted-foreground mt-1">
                    If no days are selected, all days will be used.
                  </p>
                )}
              </FormItem>
            )}
            
            <FormField
              control={form.control}
              name="reminderTime"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Reminder Time (Optional)</FormLabel>
                  <FormControl>
                    <Input type="time" {...field} />
                  </FormControl>
                  <FormDescription>
                    Set a time to receive reminders for this habit.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                disabled={createHabitMutation.isPending}
              >
                {createHabitMutation.isPending ? "Creating..." : "Create Habit"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
