import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";

interface WeeklyProgressDataPoint {
  date: string;
  day: string;
  completionRate: number;
  completed: number;
  total: number;
}

export function WeeklyProgress() {
  const { data, isLoading, error } = useQuery<WeeklyProgressDataPoint[]>({
    queryKey: ["/api/stats/weekly"],
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-semibold">Weekly Progress</CardTitle>
          <CardDescription>Your habit completion rate for the week</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex justify-between mb-3">
            {[1, 2, 3, 4, 5, 6, 7].map((day) => (
              <div key={day} className="text-center flex flex-col items-center">
                <Skeleton className="h-4 w-8 mb-2" />
                <Skeleton className="h-24 w-10 rounded-full" />
                <Skeleton className="h-4 w-8 mt-2" />
              </div>
            ))}
          </div>
          <div className="flex items-center justify-center mt-3">
            <Skeleton className="h-8 w-40 rounded-full" />
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error || !data) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-semibold">Weekly Progress</CardTitle>
          <CardDescription>Failed to load data</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center p-4 text-muted-foreground">
            Error loading weekly progress data.
          </div>
        </CardContent>
      </Card>
    );
  }

  // Calculate weekly average
  const weeklyAverage = Math.round(
    data.reduce((sum, day) => sum + day.completionRate, 0) / data.length
  );

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-lg font-semibold">Weekly Progress</CardTitle>
            <CardDescription>Your habit completion rate for the week</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex justify-between mb-3">
          {data.map((day) => (
            <div key={day.date} className="text-center flex flex-col items-center">
              <p className="text-sm text-muted-foreground mb-2">{day.day}</p>
              <div className="h-24 w-10 bg-muted rounded-full relative overflow-hidden">
                <div
                  className="absolute bottom-0 left-0 right-0 bg-primary transition-all duration-500"
                  style={{ height: `${day.completionRate}%` }}
                />
              </div>
              <p className="text-sm font-medium mt-2">{day.completionRate}%</p>
            </div>
          ))}
        </div>

        <div className="flex items-center justify-center mt-3">
          <div className="px-4 py-2 bg-primary-50 text-primary-700 rounded-full text-sm font-semibold">
            {weeklyAverage}% Weekly Average
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
