import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { HabitWithStreak } from "@shared/schema";
import { Check, Flame } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

interface HabitCardProps {
  habit: HabitWithStreak;
}

export function HabitCard({ habit }: HabitCardProps) {
  const [isCompleting, setIsCompleting] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const completeHabitMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/habits/${habit.id}/complete`, {
        date: new Date().toISOString(),
      });
      return await res.json();
    },
    onMutate: async () => {
      setIsCompleting(true);
      
      // Optimistically update the UI
      const previousData = queryClient.getQueryData<HabitWithStreak[]>(["/api/habits/today"]);
      
      if (previousData) {
        queryClient.setQueryData(
          ["/api/habits/today"],
          previousData.map((h) =>
            h.id === habit.id ? { ...h, completed: true } : h
          )
        );
      }
      
      return { previousData };
    },
    onSuccess: (data) => {
      // Update streak
      const previousData = queryClient.getQueryData<HabitWithStreak[]>(["/api/habits/today"]);
      
      if (previousData) {
        queryClient.setQueryData(
          ["/api/habits/today"],
          previousData.map((h) =>
            h.id === habit.id ? { ...h, streak: data.streak } : h
          )
        );
      }
      
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ["/api/stats/weekly"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats/streaks"] });
    },
    onError: (error, _, context) => {
      // Revert optimistic update
      if (context?.previousData) {
        queryClient.setQueryData(["/api/habits/today"], context.previousData);
      }
      
      toast({
        title: "Error completing habit",
        description: error.message,
        variant: "destructive",
      });
    },
    onSettled: () => {
      setIsCompleting(false);
    },
  });
  
  const uncompleteHabitMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest(
        "DELETE",
        `/api/habits/${habit.id}/complete`,
        undefined
      );
      return await res.json();
    },
    onMutate: async () => {
      setIsCompleting(true);
      
      // Optimistically update the UI
      const previousData = queryClient.getQueryData<HabitWithStreak[]>(["/api/habits/today"]);
      
      if (previousData) {
        queryClient.setQueryData(
          ["/api/habits/today"],
          previousData.map((h) =>
            h.id === habit.id ? { ...h, completed: false } : h
          )
        );
      }
      
      return { previousData };
    },
    onSuccess: (data) => {
      // Update streak
      const previousData = queryClient.getQueryData<HabitWithStreak[]>(["/api/habits/today"]);
      
      if (previousData) {
        queryClient.setQueryData(
          ["/api/habits/today"],
          previousData.map((h) =>
            h.id === habit.id ? { ...h, streak: data.streak } : h
          )
        );
      }
      
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ["/api/stats/weekly"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats/streaks"] });
    },
    onError: (error, _, context) => {
      // Revert optimistic update
      if (context?.previousData) {
        queryClient.setQueryData(["/api/habits/today"], context.previousData);
      }
      
      toast({
        title: "Error uncompleting habit",
        description: error.message,
        variant: "destructive",
      });
    },
    onSettled: () => {
      setIsCompleting(false);
    },
  });
  
  const toggleCompletion = () => {
    if (habit.completed) {
      uncompleteHabitMutation.mutate();
    } else {
      completeHabitMutation.mutate();
    }
  };
  
  // Format reminder time to be more readable
  const formatReminderTime = (time: string | null | undefined) => {
    if (!time) return null;
    
    try {
      const [hours, minutes] = time.split(':').map(Number);
      const date = new Date();
      date.setHours(hours, minutes);
      
      return date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
    } catch (e) {
      return time;
    }
  };
  
  // Get frequency text
  const getFrequencyText = () => {
    if (habit.frequency === 'daily') {
      return 'Daily';
    } else if (habit.frequency === 'weekly') {
      if (!habit.frequencyDays || habit.frequencyDays.length === 7) {
        return 'Every day';
      }
      
      // Map day numbers to day names
      const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
      const days = habit.frequencyDays
        ?.sort()
        .map(d => dayNames[d])
        .join(', ');
      
      return days;
    } else if (habit.frequency === 'custom') {
      if (!habit.frequencyDays || habit.frequencyDays.length === 0) {
        return 'Custom';
      }
      
      const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
      const days = habit.frequencyDays
        ?.sort()
        .map(d => dayNames[d])
        .join(', ');
      
      return days;
    }
    
    return 'Custom';
  };
  
  const reminderTime = formatReminderTime(habit.reminderTime);
  const frequencyText = getFrequencyText();
  const frequencyDisplay = reminderTime 
    ? `${frequencyText} • ${reminderTime}` 
    : frequencyText;
  
  return (
    <Card className={cn(
      "transition-all duration-200",
      habit.completed && "border-green-200 bg-green-50",
      isCompleting && "animate-pulse"
    )}>
      <CardContent className="p-4 flex items-center justify-between">
        <div className="flex items-center">
          <button
            onClick={toggleCompletion}
            disabled={isCompleting}
            className={cn(
              "relative mr-3 h-6 w-6 rounded-full border-2 flex items-center justify-center transition-colors",
              habit.completed
                ? "border-green-500 bg-green-500 hover:bg-green-600"
                : "border-primary hover:bg-primary-50"
            )}
          >
            {habit.completed && <Check className="h-4 w-4 text-white" />}
          </button>
          <div>
            <h4 className="font-medium text-foreground">{habit.name}</h4>
            <p className="text-sm text-muted-foreground">{frequencyDisplay}</p>
          </div>
        </div>
        <div className="flex items-center">
          <div className={cn(
            "flex items-center px-2 py-1 rounded-md text-sm",
            habit.completed
              ? "bg-green-100 text-green-700"
              : "bg-primary-50 text-primary-700"
          )}>
            <Flame className="h-4 w-4 mr-1" />
            <span>{habit.streak}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
