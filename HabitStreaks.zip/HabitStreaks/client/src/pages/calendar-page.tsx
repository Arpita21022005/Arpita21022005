import { useState, useEffect } from "react";
import { NavBar } from "@/components/nav-bar";
import { useQuery } from "@tanstack/react-query";
import { Calendar } from "@/components/ui/calendar";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { addDays, format, startOfMonth, endOfMonth, isSameDay } from "date-fns";
import { Loader2 } from "lucide-react";
import { HabitCard } from "@/components/habit-card";
import { HabitWithStreak } from "@shared/schema";

interface Completion {
  id: number;
  habitId: number;
  userId: number;
  completedAt: string;
}

export default function CalendarPage() {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());

  // Get completions for the current month
  const { data: completions, isLoading: completionsLoading } = useQuery<Completion[]>({
    queryKey: [
      "/api/completions",
      selectedDate ? format(startOfMonth(selectedDate), "yyyy-MM-dd") : null,
      selectedDate ? format(endOfMonth(selectedDate), "yyyy-MM-dd") : null,
    ],
    enabled: !!selectedDate,
  });

  // Get habits for the selected date
  const { data: habits, isLoading: habitsLoading } = useQuery<HabitWithStreak[]>({
    queryKey: [
      "/api/habits/today",
      selectedDate ? format(selectedDate, "yyyy-MM-dd") : null,
    ],
    enabled: !!selectedDate,
  });

  // Generate date structure to highlight days with completions
  const getDayHighlights = () => {
    if (!completions) return {};
    
    const completionDays: Record<string, string> = {};
    
    completions.forEach((completion) => {
      const date = format(new Date(completion.completedAt), "yyyy-MM-dd");
      completionDays[date] = "completed";
    });
    
    return completionDays;
  };

  const dayHighlights = getDayHighlights();

  return (
    <div className="min-h-screen pb-20 md:pb-0">
      <NavBar />
      
      <main className="container mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold mb-6">Calendar</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-[350px_1fr] gap-6">
          <Card className="border bg-card">
            <CardHeader className="pb-2">
              <CardTitle>Habit Calendar</CardTitle>
              <CardDescription>
                View your habits and completions by date
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                className="rounded-md border"
                modifiers={{
                  completed: (date) => {
                    const dateStr = format(date, "yyyy-MM-dd");
                    return dateStr in dayHighlights;
                  },
                }}
                modifiersStyles={{
                  completed: {
                    backgroundColor: "hsl(var(--primary-50))",
                    borderRadius: "0",
                  },
                }}
                disabled={{
                  after: addDays(new Date(), 0),
                }}
              />
            </CardContent>
          </Card>
          
          <div>
            <Card className="border bg-card">
              <CardHeader className="pb-4">
                <CardTitle>
                  {selectedDate ? format(selectedDate, "EEEE, MMMM d, yyyy") : "Select a date"}
                </CardTitle>
                <CardDescription>
                  {habits
                    ? `${habits.filter((h) => h.completed).length} of ${
                        habits.length
                      } habits completed`
                    : "Loading habit data..."}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {habitsLoading ? (
                  <div className="flex items-center justify-center p-8">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : habits && habits.length > 0 ? (
                  <div className="space-y-3">
                    {habits.map((habit) => (
                      <HabitCard key={habit.id} habit={habit} />
                    ))}
                  </div>
                ) : (
                  <div className="text-center p-8 text-muted-foreground">
                    {isSameDay(selectedDate!, new Date())
                      ? "No habits scheduled for today."
                      : "No habits scheduled for this date."}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
