import { useState, useEffect } from "react";
import { format, parseISO } from "date-fns";
import { useQuery } from "@tanstack/react-query";
import { HabitWithStreak } from "@shared/schema";
import { HabitCard } from "@/components/habit-card";
import { WeeklyProgress } from "@/components/weekly-progress";
import { TopStreaks } from "@/components/top-streaks";
import { NavBar } from "@/components/nav-bar";
import { Skeleton } from "@/components/ui/skeleton";

export default function HomePage() {
  const [currentDate, setCurrentDate] = useState(new Date());
  
  const {
    data: habits,
    isLoading,
    error,
  } = useQuery<HabitWithStreak[]>({
    queryKey: ["/api/habits/today"],
  });

  // Format date to display on the page
  const formattedDate = format(currentDate, "EEEE, MMMM d");

  // Calculate completion summary
  const completionSummary = habits 
    ? `${habits.filter(h => h.completed).length} of ${habits.length} habits completed today`
    : "Loading habits...";

  return (
    <div className="min-h-screen pb-20 md:pb-0">
      <NavBar />
      
      <main className="container mx-auto px-4 py-6">
        <div className="mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-semibold">{formattedDate}</h2>
              <p className="text-muted-foreground text-sm">{completionSummary}</p>
            </div>
            
            {habits && habits.length > 0 && (
              <div className="bg-primary-50 text-primary-700 px-3 py-1 rounded-full text-sm font-medium">
                {Math.round((habits.filter(h => h.completed).length / habits.length) * 100)}% today
              </div>
            )}
          </div>
        </div>
        
        <section className="mb-8">
          <h3 className="text-lg font-semibold mb-4">Today's Habits</h3>
          
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="bg-card rounded-lg p-4 flex items-center justify-between">
                  <div className="flex items-center">
                    <Skeleton className="h-6 w-6 rounded-full mr-3" />
                    <div>
                      <Skeleton className="h-4 w-40 mb-2" />
                      <Skeleton className="h-3 w-24" />
                    </div>
                  </div>
                  <Skeleton className="h-8 w-12 rounded-md" />
                </div>
              ))}
            </div>
          ) : error ? (
            <div className="p-8 text-center">
              <p className="text-muted-foreground">Error loading habits</p>
            </div>
          ) : habits && habits.length > 0 ? (
            <div className="space-y-3">
              {habits.map((habit) => (
                <HabitCard key={habit.id} habit={habit} />
              ))}
            </div>
          ) : (
            <div className="bg-card rounded-lg border border-border p-8 text-center">
              <h4 className="font-medium text-lg mb-2">No habits for today</h4>
              <p className="text-muted-foreground mb-4">Create a new habit to get started tracking</p>
            </div>
          )}
        </section>
        
        <section className="mb-8">
          <WeeklyProgress />
        </section>
        
        <section>
          <TopStreaks />
        </section>
      </main>
    </div>
  );
}
