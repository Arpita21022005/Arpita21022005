import { useState } from "react";
import { NavBar } from "@/components/nav-bar";
import { useQuery } from "@tanstack/react-query";
import { WeeklyProgress } from "@/components/weekly-progress";
import { TopStreaks } from "@/components/top-streaks";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";
import { Loader2 } from "lucide-react";

interface WeeklyProgressDataPoint {
  date: string;
  day: string;
  completionRate: number;
  completed: number;
  total: number;
}

interface TopStreak {
  habitId: number;
  name: string;
  streak: number;
}

const COLORS = ["#6366F1", "#818CF8", "#A5B4FC", "#C7D2FE", "#E0E7FF"];

export default function StatsPage() {
  const [activeTab, setActiveTab] = useState("progress");
  
  const { data: weeklyData, isLoading: weeklyLoading } = useQuery<WeeklyProgressDataPoint[]>({
    queryKey: ["/api/stats/weekly"],
  });
  
  const { data: topStreaks, isLoading: streaksLoading } = useQuery<TopStreak[]>({
    queryKey: ["/api/stats/streaks"],
  });
  
  // Prepare data for the charts
  const prepareCompletionData = () => {
    if (!weeklyData) return [];
    
    let total = 0;
    let completed = 0;
    
    weeklyData.forEach(day => {
      total += day.total;
      completed += day.completed;
    });
    
    return [
      { name: "Completed", value: completed },
      { name: "Missed", value: total - completed },
    ];
  };
  
  const prepareStreakData = () => {
    if (!topStreaks) return [];
    
    return topStreaks.map(streak => ({
      name: streak.name,
      streak: streak.streak,
    }));
  };
  
  const completionData = prepareCompletionData();
  const streakData = prepareStreakData();

  return (
    <div className="min-h-screen pb-20 md:pb-0">
      <NavBar />
      
      <main className="container mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold mb-6">Statistics</h1>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 md:w-[400px]">
            <TabsTrigger value="progress">Progress</TabsTrigger>
            <TabsTrigger value="streaks">Streaks</TabsTrigger>
          </TabsList>
          
          <TabsContent value="progress" className="space-y-6 mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Weekly Overview</CardTitle>
                  <CardDescription>Your habit completion rate for this week</CardDescription>
                </CardHeader>
                <CardContent className="h-[300px]">
                  {weeklyLoading ? (
                    <div className="flex items-center justify-center h-full">
                      <Loader2 className="h-8 w-8 animate-spin text-primary" />
                    </div>
                  ) : weeklyData && weeklyData.length > 0 ? (
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={weeklyData}
                        margin={{ top: 20, right: 30, left: 0, bottom: 20 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="day" />
                        <YAxis unit="%" domain={[0, 100]} />
                        <Tooltip formatter={(value) => [`${value}%`, "Completion Rate"]} />
                        <Bar dataKey="completionRate" fill="#6366F1" />
                      </BarChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="flex items-center justify-center h-full">
                      <p className="text-muted-foreground">No data available</p>
                    </div>
                  )}
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Completion Rate</CardTitle>
                  <CardDescription>Completed vs. missed habits</CardDescription>
                </CardHeader>
                <CardContent className="h-[300px]">
                  {weeklyLoading ? (
                    <div className="flex items-center justify-center h-full">
                      <Loader2 className="h-8 w-8 animate-spin text-primary" />
                    </div>
                  ) : completionData && completionData.length > 0 ? (
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={completionData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        >
                          {completionData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={index === 0 ? "#6366F1" : "#E0E7FF"} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => [value, "Habits"]} />
                      </PieChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="flex items-center justify-center h-full">
                      <p className="text-muted-foreground">No data available</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
            
            <WeeklyProgress />
          </TabsContent>
          
          <TabsContent value="streaks" className="space-y-6 mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Current Streak Leaders</CardTitle>
                <CardDescription>Your longest running habits</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                {streaksLoading ? (
                  <div className="flex items-center justify-center h-full">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : streakData && streakData.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={streakData}
                      layout="vertical"
                      margin={{ top: 5, right: 30, left: 100, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" domain={[0, 'dataMax + 2']} />
                      <YAxis type="category" dataKey="name" width={100} />
                      <Tooltip formatter={(value) => [`${value} days`, "Streak"]} />
                      <Bar dataKey="streak" fill="#6366F1">
                        {streakData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex items-center justify-center h-full">
                    <p className="text-muted-foreground">No streak data available</p>
                  </div>
                )}
              </CardContent>
            </Card>
            
            <TopStreaks />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
