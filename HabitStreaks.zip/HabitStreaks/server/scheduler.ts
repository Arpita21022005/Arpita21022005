import schedule from 'node-schedule';
import { storage } from './storage';
import { format } from 'date-fns';

interface ReminderJob {
  jobId: string;
  userId: number;
  habitId: number;
  reminderTime: string;
}

class NotificationScheduler {
  private jobs: Map<string, schedule.Job>;
  private subscribers: Map<number, Set<(message: any) => void>>;

  constructor() {
    this.jobs = new Map();
    this.subscribers = new Map();
  }

  async initializeReminders() {
    // This would be typically done on server start, we'd load all habits with reminders
    // For this demo, we'll only schedule reminders as they are created
  }

  async scheduleReminder(userId: number, habitId: number, time: string) {
    try {
      const habit = await storage.getHabit(habitId);
      if (!habit) return false;

      // Cancel existing job if there is one
      this.cancelReminder(userId, habitId);

      // Parse time (HH:MM)
      const [hours, minutes] = time.split(':').map(Number);
      if (isNaN(hours) || isNaN(minutes)) return false;

      // Create a schedule rule
      const rule = new schedule.RecurrenceRule();
      rule.hour = hours;
      rule.minute = minutes;
      rule.tz = 'UTC'; // You might want to store user timezone in production

      // Create a unique job ID
      const jobId = `reminder-${userId}-${habitId}`;

      // Schedule the job
      const job = schedule.scheduleJob(rule, async () => {
        const habitDetails = await storage.getHabit(habitId);
        if (!habitDetails) return;

        const today = new Date();
        const dayOfWeek = today.getDay();
        let shouldSendReminder = false;

        // Check if the habit is due today based on frequency
        if (habit.frequency === 'daily') {
          shouldSendReminder = true;
        } else if (habit.frequency === 'weekly' || habit.frequency === 'custom') {
          shouldSendReminder = habit.frequencyDays?.includes(dayOfWeek) ?? false;
        }

        if (shouldSendReminder) {
          // Check if the habit has been completed today
          const todayStr = format(today, 'yyyy-MM-dd');
          const completions = await storage.getHabitCompletions(habitId);
          const completedToday = completions.some(c => {
            const completionDate = (c.completedAt instanceof Date) 
              ? c.completedAt 
              : new Date(c.completedAt);
            return format(completionDate, 'yyyy-MM-dd') === todayStr;
          });

          if (!completedToday) {
            // Send notification to user
            this.notifyUser(userId, {
              type: 'REMINDER',
              habitId,
              habitName: habitDetails.name,
              time: format(today, 'h:mm aa'),
              message: `Don't forget to ${habitDetails.name} today!`,
            });
          }
        }
      });

      // Store the job
      this.jobs.set(jobId, job);

      return true;
    } catch (error) {
      console.error('Error scheduling reminder:', error);
      return false;
    }
  }

  cancelReminder(userId: number, habitId: number) {
    const jobId = `reminder-${userId}-${habitId}`;
    const job = this.jobs.get(jobId);
    
    if (job) {
      job.cancel();
      this.jobs.delete(jobId);
      return true;
    }
    
    return false;
  }

  // For clients to subscribe to notifications
  subscribe(userId: number, callback: (message: any) => void) {
    if (!this.subscribers.has(userId)) {
      this.subscribers.set(userId, new Set());
    }
    
    this.subscribers.get(userId)?.add(callback);
    
    return () => {
      const userSubscribers = this.subscribers.get(userId);
      if (userSubscribers) {
        userSubscribers.delete(callback);
        if (userSubscribers.size === 0) {
          this.subscribers.delete(userId);
        }
      }
    };
  }

  // Send notification to a user
  notifyUser(userId: number, message: any) {
    const userSubscribers = this.subscribers.get(userId);
    if (userSubscribers) {
      userSubscribers.forEach(callback => {
        try {
          callback(message);
        } catch (error) {
          console.error('Error calling notification callback:', error);
        }
      });
    }
  }
}

export const notificationScheduler = new NotificationScheduler();
