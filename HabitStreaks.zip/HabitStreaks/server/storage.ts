import { users, type User, type InsertUser, habits, type Habit, type InsertHabit, completions, type Completion, type InsertCompletion } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";
import { subDays, format, parseISO, isWithinInterval, addDays } from "date-fns";

const MemoryStore = createMemoryStore(session);

// modify the interface with any CRUD methods
// you might need
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Habit methods
  getHabits(userId: number): Promise<Habit[]>;
  getHabit(id: number): Promise<Habit | undefined>;
  createHabit(habit: InsertHabit & { userId: number }): Promise<Habit>;
  updateHabit(id: number, habit: Partial<InsertHabit>): Promise<Habit | undefined>;
  deleteHabit(id: number): Promise<boolean>;

  // Completion methods
  getCompletions(userId: number, fromDate?: string, toDate?: string): Promise<Completion[]>;
  getHabitCompletions(habitId: number, fromDate?: string, toDate?: string): Promise<Completion[]>;
  createCompletion(completion: InsertCompletion & { userId: number }): Promise<Completion>;
  deleteCompletion(habitId: number, date: string, userId: number): Promise<boolean>;
  
  // Stats methods
  getCurrentStreak(habitId: number): Promise<number>;
  getLongestStreak(habitId: number): Promise<number>;
  getTopStreaks(userId: number, limit?: number): Promise<Array<{ habitId: number; streak: number }>>;
  getCompletionRate(userId: number, days?: number): Promise<number>;
  getHabitsWithStreaks(userId: number, date?: string): Promise<Array<Habit & { streak: number; completed: boolean }>>;
  
  // Session store
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private habits: Map<number, Habit>;
  private completions: Map<number, Completion>;
  sessionStore: session.SessionStore;
  private userId: number;
  private habitId: number;
  private completionId: number;

  constructor() {
    this.users = new Map();
    this.habits = new Map();
    this.completions = new Map();
    this.userId = 1;
    this.habitId = 1;
    this.completionId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: new Date() 
    };
    this.users.set(id, user);
    return user;
  }

  // Habit methods
  async getHabits(userId: number): Promise<Habit[]> {
    return Array.from(this.habits.values()).filter(
      (habit) => habit.userId === userId,
    );
  }

  async getHabit(id: number): Promise<Habit | undefined> {
    return this.habits.get(id);
  }

  async createHabit(habit: InsertHabit & { userId: number }): Promise<Habit> {
    const id = this.habitId++;
    const newHabit: Habit = {
      ...habit,
      id,
      createdAt: new Date(),
    };
    this.habits.set(id, newHabit);
    return newHabit;
  }

  async updateHabit(id: number, habitUpdate: Partial<InsertHabit>): Promise<Habit | undefined> {
    const habit = this.habits.get(id);
    if (!habit) return undefined;

    const updatedHabit = { ...habit, ...habitUpdate };
    this.habits.set(id, updatedHabit);
    return updatedHabit;
  }

  async deleteHabit(id: number): Promise<boolean> {
    return this.habits.delete(id);
  }

  // Completion methods
  async getCompletions(userId: number, fromDate?: string, toDate?: string): Promise<Completion[]> {
    const userCompletions = Array.from(this.completions.values()).filter(
      (completion) => completion.userId === userId
    );

    if (!fromDate && !toDate) return userCompletions;

    const start = fromDate ? parseISO(fromDate) : new Date(0);
    const end = toDate ? parseISO(toDate) : new Date();

    return userCompletions.filter((completion) => {
      const completedDate = completion.completedAt instanceof Date 
        ? completion.completedAt 
        : parseISO(completion.completedAt.toString());
      
      return isWithinInterval(completedDate, { start, end });
    });
  }

  async getHabitCompletions(habitId: number, fromDate?: string, toDate?: string): Promise<Completion[]> {
    const habitCompletions = Array.from(this.completions.values()).filter(
      (completion) => completion.habitId === habitId
    );

    if (!fromDate && !toDate) return habitCompletions;

    const start = fromDate ? parseISO(fromDate) : new Date(0);
    const end = toDate ? parseISO(toDate) : new Date();

    return habitCompletions.filter((completion) => {
      const completedDate = completion.completedAt instanceof Date 
        ? completion.completedAt 
        : parseISO(completion.completedAt.toString());
      
      return isWithinInterval(completedDate, { start, end });
    });
  }

  async createCompletion(completion: InsertCompletion & { userId: number }): Promise<Completion> {
    const id = this.completionId++;
    const newCompletion: Completion = {
      ...completion,
      id,
    };
    this.completions.set(id, newCompletion);
    return newCompletion;
  }

  async deleteCompletion(habitId: number, date: string, userId: number): Promise<boolean> {
    const formattedDate = format(parseISO(date), 'yyyy-MM-dd');
    
    for (const [id, completion] of this.completions.entries()) {
      const completionDate = format(
        completion.completedAt instanceof Date 
          ? completion.completedAt 
          : parseISO(completion.completedAt.toString()),
        'yyyy-MM-dd'
      );
      
      if (completion.habitId === habitId && completion.userId === userId && completionDate === formattedDate) {
        return this.completions.delete(id);
      }
    }
    
    return false;
  }

  // Stats methods
  async getCurrentStreak(habitId: number): Promise<number> {
    const habit = await this.getHabit(habitId);
    if (!habit) return 0;
    
    const today = new Date();
    const completions = await this.getHabitCompletions(habitId);
    
    // Sort completions by date, most recent first
    const sortedCompletions = completions
      .map(c => ({
        ...c,
        date: c.completedAt instanceof Date ? c.completedAt : parseISO(c.completedAt.toString())
      }))
      .sort((a, b) => b.date.getTime() - a.date.getTime());
    
    if (sortedCompletions.length === 0) return 0;
    
    let streak = 0;
    let currentDate = today;
    let checkingToday = true;
    
    // Handle different frequency types
    const isHabitDueOnDate = (date: Date) => {
      const dayOfWeek = date.getDay(); // 0 = Sunday, 6 = Saturday
      
      if (habit.frequency === 'daily') {
        return true;
      } else if (habit.frequency === 'weekly') {
        return habit.frequencyDays?.includes(dayOfWeek) ?? false;
      } else if (habit.frequency === 'custom' && habit.frequencyDays) {
        return habit.frequencyDays.includes(dayOfWeek);
      }
      
      return false;
    };
    
    // Check if we have completed the habit today
    const todayStr = format(today, 'yyyy-MM-dd');
    const completedToday = sortedCompletions.some(c => 
      format(c.date, 'yyyy-MM-dd') === todayStr
    );
    
    if (completedToday) {
      streak = 1;
    } else if (!isHabitDueOnDate(today)) {
      // If the habit is not due today, we can still have a streak
      // We'll start checking from yesterday instead
      currentDate = subDays(today, 1);
      checkingToday = false;
    } else {
      // If habit is due today but not completed, no streak
      return 0;
    }
    
    // If we're not checking today (because it's not due today), or if we've completed it today
    if (!checkingToday || completedToday) {
      let dayToCheck = checkingToday ? subDays(today, 1) : currentDate;
      let keepChecking = true;
      
      while (keepChecking) {
        const dateStr = format(dayToCheck, 'yyyy-MM-dd');
        const isCompleted = sortedCompletions.some(c => 
          format(c.date, 'yyyy-MM-dd') === dateStr
        );
        
        if (isHabitDueOnDate(dayToCheck)) {
          if (isCompleted) {
            streak += 1;
          } else {
            keepChecking = false;
          }
        }
        
        dayToCheck = subDays(dayToCheck, 1);
        
        // Stop if we go back more than a year (safety check)
        if (dayToCheck.getTime() < subDays(today, 365).getTime()) {
          keepChecking = false;
        }
      }
    }
    
    return streak;
  }

  async getLongestStreak(habitId: number): Promise<number> {
    const habit = await this.getHabit(habitId);
    if (!habit) return 0;
    
    const completions = await this.getHabitCompletions(habitId);
    if (completions.length === 0) return 0;
    
    // Convert to dates and sort by date
    const dates = completions
      .map(c => c.completedAt instanceof Date ? c.completedAt : parseISO(c.completedAt.toString()))
      .sort((a, b) => a.getTime() - b.getTime());
    
    // Group dates by streak
    const isHabitDueOnDate = (date: Date) => {
      const dayOfWeek = date.getDay();
      
      if (habit.frequency === 'daily') {
        return true;
      } else if (habit.frequency === 'weekly') {
        return habit.frequencyDays?.includes(dayOfWeek) ?? false;
      } else if (habit.frequency === 'custom' && habit.frequencyDays) {
        return habit.frequencyDays.includes(dayOfWeek);
      }
      
      return false;
    };
    
    let longestStreak = 0;
    let currentStreak = 0;
    let previousDate: Date | null = null;
    
    for (let i = 0; i < dates.length; i++) {
      const currentDate = dates[i];
      const dateStr = format(currentDate, 'yyyy-MM-dd');
      
      // If this is the first date, start a streak
      if (previousDate === null) {
        currentStreak = 1;
        previousDate = currentDate;
        continue;
      }
      
      // Check all days between previous date and current date
      let tempDate = addDays(previousDate, 1);
      let streakBroken = false;
      
      while (tempDate < currentDate && !streakBroken) {
        if (isHabitDueOnDate(tempDate)) {
          // If a habit was due but not completed, break the streak
          streakBroken = true;
        }
        tempDate = addDays(tempDate, 1);
      }
      
      if (streakBroken) {
        // Update longest streak if needed
        longestStreak = Math.max(longestStreak, currentStreak);
        currentStreak = 1;
      } else {
        // If same day, don't count twice
        if (format(previousDate, 'yyyy-MM-dd') !== dateStr) {
          currentStreak += 1;
        }
      }
      
      previousDate = currentDate;
    }
    
    // Final check for the longest streak
    return Math.max(longestStreak, currentStreak);
  }

  async getTopStreaks(userId: number, limit: number = 3): Promise<Array<{ habitId: number; streak: number }>> {
    const userHabits = await this.getHabits(userId);
    const streaks: Array<{ habitId: number; streak: number }> = [];
    
    for (const habit of userHabits) {
      const streak = await this.getCurrentStreak(habit.id);
      streaks.push({ habitId: habit.id, streak });
    }
    
    return streaks
      .sort((a, b) => b.streak - a.streak)
      .slice(0, limit);
  }

  async getCompletionRate(userId: number, days: number = 7): Promise<number> {
    const userHabits = await this.getHabits(userId);
    if (userHabits.length === 0) return 0;
    
    const today = new Date();
    const startDate = subDays(today, days - 1); // Include today
    
    let totalCompleted = 0;
    let totalDue = 0;
    
    for (let i = 0; i < days; i++) {
      const date = i === 0 ? today : subDays(today, i);
      const dayOfWeek = date.getDay();
      
      for (const habit of userHabits) {
        let isDue = false;
        
        if (habit.frequency === 'daily') {
          isDue = true;
        } else if (habit.frequency === 'weekly' || habit.frequency === 'custom') {
          isDue = habit.frequencyDays?.includes(dayOfWeek) ?? false;
        }
        
        if (isDue) {
          totalDue++;
          
          const dateStr = format(date, 'yyyy-MM-dd');
          const completions = await this.getHabitCompletions(habit.id);
          const isCompleted = completions.some(c => {
            const completionDate = c.completedAt instanceof Date 
              ? c.completedAt 
              : parseISO(c.completedAt.toString());
            return format(completionDate, 'yyyy-MM-dd') === dateStr;
          });
          
          if (isCompleted) {
            totalCompleted++;
          }
        }
      }
    }
    
    return totalDue > 0 ? totalCompleted / totalDue : 0;
  }

  async getHabitsWithStreaks(userId: number, dateStr?: string): Promise<Array<Habit & { streak: number; completed: boolean }>> {
    const date = dateStr ? parseISO(dateStr) : new Date();
    const formattedDate = format(date, 'yyyy-MM-dd');
    const dayOfWeek = date.getDay();
    
    const userHabits = await this.getHabits(userId);
    const result: Array<Habit & { streak: number; completed: boolean }> = [];
    
    for (const habit of userHabits) {
      let isDue = false;
      
      if (habit.frequency === 'daily') {
        isDue = true;
      } else if (habit.frequency === 'weekly' || habit.frequency === 'custom') {
        isDue = habit.frequencyDays?.includes(dayOfWeek) ?? false;
      }
      
      if (isDue) {
        const streak = await this.getCurrentStreak(habit.id);
        const completions = await this.getHabitCompletions(habit.id);
        
        const completed = completions.some(c => {
          const completionDate = c.completedAt instanceof Date 
            ? c.completedAt 
            : parseISO(c.completedAt.toString());
          return format(completionDate, 'yyyy-MM-dd') === formattedDate;
        });
        
        result.push({ ...habit, streak, completed });
      }
    }
    
    return result;
  }
}

export const storage = new MemStorage();
