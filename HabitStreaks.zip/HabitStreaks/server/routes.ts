import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { notificationScheduler } from "./scheduler";
import { format, parseISO, endOfWeek, startOfWeek, addDays, subDays } from "date-fns";
import WebSocket from 'ws';

const isAuthenticated = (req: any, res: any, next: any) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Not authenticated" });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  // Habit routes
  app.get("/api/habits", isAuthenticated, async (req, res) => {
    try {
      const habits = await storage.getHabits(req.user!.id);
      res.json(habits);
    } catch (error) {
      res.status(500).json({ message: "Error fetching habits" });
    }
  });

  app.get("/api/habits/today", isAuthenticated, async (req, res) => {
    try {
      const date = req.query.date ? String(req.query.date) : undefined;
      const habitsWithStreaks = await storage.getHabitsWithStreaks(req.user!.id, date);
      res.json(habitsWithStreaks);
    } catch (error) {
      res.status(500).json({ message: "Error fetching today's habits" });
    }
  });

  app.post("/api/habits", isAuthenticated, async (req, res) => {
    try {
      const habit = await storage.createHabit({
        ...req.body,
        userId: req.user!.id,
      });

      // Schedule reminder if one is set
      if (habit.reminderTime) {
        await notificationScheduler.scheduleReminder(
          req.user!.id,
          habit.id,
          habit.reminderTime
        );
      }

      res.status(201).json(habit);
    } catch (error) {
      res.status(500).json({ message: "Error creating habit" });
    }
  });

  app.put("/api/habits/:id", isAuthenticated, async (req, res) => {
    try {
      const habitId = parseInt(req.params.id);
      const habit = await storage.getHabit(habitId);

      if (!habit) {
        return res.status(404).json({ message: "Habit not found" });
      }

      if (habit.userId !== req.user!.id) {
        return res.status(403).json({ message: "Not authorized" });
      }

      const updatedHabit = await storage.updateHabit(habitId, req.body);

      // Update reminder if needed
      if (req.body.reminderTime !== undefined) {
        if (req.body.reminderTime) {
          await notificationScheduler.scheduleReminder(
            req.user!.id,
            habitId,
            req.body.reminderTime
          );
        } else {
          notificationScheduler.cancelReminder(req.user!.id, habitId);
        }
      }

      res.json(updatedHabit);
    } catch (error) {
      res.status(500).json({ message: "Error updating habit" });
    }
  });

  app.delete("/api/habits/:id", isAuthenticated, async (req, res) => {
    try {
      const habitId = parseInt(req.params.id);
      const habit = await storage.getHabit(habitId);

      if (!habit) {
        return res.status(404).json({ message: "Habit not found" });
      }

      if (habit.userId !== req.user!.id) {
        return res.status(403).json({ message: "Not authorized" });
      }

      await storage.deleteHabit(habitId);

      // Cancel any reminders
      notificationScheduler.cancelReminder(req.user!.id, habitId);

      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Error deleting habit" });
    }
  });

  // Completion routes
  app.post("/api/habits/:id/complete", isAuthenticated, async (req, res) => {
    try {
      const habitId = parseInt(req.params.id);
      const habit = await storage.getHabit(habitId);

      if (!habit) {
        return res.status(404).json({ message: "Habit not found" });
      }

      if (habit.userId !== req.user!.id) {
        return res.status(403).json({ message: "Not authorized" });
      }

      const date = req.body.date ? req.body.date : format(new Date(), 'yyyy-MM-dd\'T\'HH:mm:ss.SSS\'Z\'');
      
      const completion = await storage.createCompletion({
        habitId,
        userId: req.user!.id,
        completedAt: date,
      });

      const updatedStreak = await storage.getCurrentStreak(habitId);
      
      res.status(201).json({ 
        ...completion, 
        streak: updatedStreak 
      });
    } catch (error) {
      res.status(500).json({ message: "Error completing habit" });
    }
  });

  app.delete("/api/habits/:id/complete", isAuthenticated, async (req, res) => {
    try {
      const habitId = parseInt(req.params.id);
      const habit = await storage.getHabit(habitId);

      if (!habit) {
        return res.status(404).json({ message: "Habit not found" });
      }

      if (habit.userId !== req.user!.id) {
        return res.status(403).json({ message: "Not authorized" });
      }

      const date = req.query.date ? String(req.query.date) : format(new Date(), 'yyyy-MM-dd');
      
      await storage.deleteCompletion(habitId, date, req.user!.id);
      
      const updatedStreak = await storage.getCurrentStreak(habitId);
      
      res.json({ 
        habitId,
        deleted: true,
        streak: updatedStreak
      });
    } catch (error) {
      res.status(500).json({ message: "Error uncompleting habit" });
    }
  });

  app.get("/api/completions", isAuthenticated, async (req, res) => {
    try {
      const fromDate = req.query.from ? String(req.query.from) : undefined;
      const toDate = req.query.to ? String(req.query.to) : undefined;
      
      const completions = await storage.getCompletions(req.user!.id, fromDate, toDate);
      res.json(completions);
    } catch (error) {
      res.status(500).json({ message: "Error fetching completions" });
    }
  });

  // Stats routes
  app.get("/api/stats/weekly", isAuthenticated, async (req, res) => {
    try {
      const today = new Date();
      const start = startOfWeek(today, { weekStartsOn: 1 }); // Start week on Monday
      const weekData = [];
      
      // Get all habits for this user
      const habits = await storage.getHabits(req.user!.id);
      
      // For each day of the week
      for (let i = 0; i < 7; i++) {
        const currentDate = addDays(start, i);
        const dateStr = format(currentDate, 'yyyy-MM-dd');
        const dayOfWeek = currentDate.getDay();
        
        let completed = 0;
        let total = 0;
        
        // Calculate completion rate for this day
        for (const habit of habits) {
          let isDue = false;
          
          if (habit.frequency === 'daily') {
            isDue = true;
          } else if (habit.frequency === 'weekly' || habit.frequency === 'custom') {
            isDue = habit.frequencyDays?.includes(dayOfWeek) ?? false;
          }
          
          if (isDue) {
            total++;
            
            const completions = await storage.getHabitCompletions(habit.id, dateStr, dateStr);
            if (completions.length > 0) {
              completed++;
            }
          }
        }
        
        const completionRate = total > 0 ? (completed / total) * 100 : 0;
        
        weekData.push({
          date: dateStr,
          day: format(currentDate, 'EEE'),
          completionRate: Math.round(completionRate),
          completed,
          total,
        });
      }
      
      res.json(weekData);
    } catch (error) {
      res.status(500).json({ message: "Error fetching weekly stats" });
    }
  });

  app.get("/api/stats/streaks", isAuthenticated, async (req, res) => {
    try {
      const topStreaks = await storage.getTopStreaks(req.user!.id, 5);
      
      // Enrich with habit details
      const enrichedStreaks = await Promise.all(
        topStreaks.map(async ({ habitId, streak }) => {
          const habit = await storage.getHabit(habitId);
          return {
            habitId,
            name: habit?.name || 'Unknown Habit',
            streak
          };
        })
      );
      
      res.json(enrichedStreaks);
    } catch (error) {
      res.status(500).json({ message: "Error fetching top streaks" });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);

  // Setup WebSocket server for real-time notifications
  // Either disable WebSocket for now to get the application working
  // or use the proper syntax based on commonjs import
  
  // For now, we'll comment out the WebSocket functionality to get the app running
  /* 
  const wss = new WebSocket.Server({ server: httpServer });

  wss.on('connection', (ws, req) => {
    // Authentication would be handled here in a real app
    // For this demo, we'll use a simple userId query param
    const url = new URL(req.url || '', `http://${req.headers.host}`);
    const userId = parseInt(url.searchParams.get('userId') || '0');

    if (!userId) {
      ws.close();
      return;
    }

    // Subscribe to notifications for this user
    const unsubscribe = notificationScheduler.subscribe(userId, (message) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify(message));
      }
    });

    ws.on('close', () => {
      unsubscribe();
    });
  });
  */

  return httpServer;
}
